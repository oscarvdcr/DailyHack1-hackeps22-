import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Main {
        //Grid length and height
    public static void main(String args[]) throws InterruptedException, IOException {
        int h=11, l=18;
        //Grid for pattern
        //The proposed seed is already in the grid. 6th row, 5th column, 10 alive cells in a row.
        int[][] grid = {                                                //grid with zeros to reset
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0}, //{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, //{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}  //{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
        };


        //let the user decide the mode
        System.out.println("Select option: 1-.Automatic 2-.Manual");
        //ascii --> dec
        int op = System.in.read() - 48;

        //auto mode
        if (op == 1){
            System.out.println("Starting game...");
            while (true){
                Display(grid,h,l);
                //delay between gens
                TimeUnit.MILLISECONDS.sleep(600);
                nextGen(grid,h,l);
            }
        //manual mode
        }else if(op == 2){
            System.out.println("Starting game...");
            while (true){
                Display(grid,h,l);
                System.out.println("Press enter for next generation");
                //wait for input to go next gen
                System.in.read();
                nextGen(grid,h,l);
            }
        }else{
            //error msg
            System.out.println("Error. Select a valid option");
        }
    }

    public static void Display(int grid[][], int h, int l) {
        //display grid on console
        //make pop-up window?
        System.out.println("Next Generation");
        for (int i=0; i<h; i++){
            for (int j=0; j<l; j++){
                //dead == 0 && alive == 1
                if (grid[i][j] == 0){
                    System.out.print("░░ ");
                }else{
                    System.out.print("██ ");
                }
            }
            System.out.println();
        }
        System.out.println();
    }

    static void nextGen(int grid[][], int h, int l) {
        int[][] newGrid = new int[h][l];

        // Loop through every cell
        for (int x = 0; x < h; x++)
        {
            for (int y = 0; y < l; y++)
            {
                //Finding num of near cells that are alive
                int aliveCells = 0;
                for (int i = -1; i <= 1; i++)
                    for (int j = -1; j <= 1; j++)
                        if ((x+i>=0 && x+i<h) && (y+j>=0 && y+j<l))
                            aliveCells += grid[x + i][y + j];

                //Don't count the cell we are looking at.
                aliveCells -= grid[x][y];

                //Rules of the game
                if ((grid[x][y] == 1) && (aliveCells < 2)) {
                    //My social life. Lack of near alive cells.
                    newGrid[x][y] = 0;
                } else if ((grid[x][y] == 1) && (aliveCells > 3)){
                    //Cell party. They partied too hard and died.
                    newGrid[x][y] = 0;
                } else if ((grid[x][y] == 0) && (aliveCells == 3)){
                    //Balanced, as all things should be.
                    newGrid[x][y] = 1;
                } else {
                    //Boring cell. Does nothing.
                    newGrid[x][y] = grid[x][y];
                }
            }
        }
        //Puts the new gen on a new grid
        for (int i=0; i<h; i++){
            for (int j=0; j<l; j++){
                grid[i][j] = newGrid[i][j];
            }
        }
    }
}
//End of code.